# Form Pagination - Visual Feature Overview

## 1. Form Builder (Admin View)
```
┌─────────────────────────────────────────────────────────────────┐
│ Crear Formulario                                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Nombre: [Solicitud de Visa Americana                       ]   │
│                                                                 │
│ Tipo: [Visa ▼]  Subtipo: [Primera Vez                     ]   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ ☑ Insertar Paginación                                   │   │
│ │   Divide el formulario en secciones para guardar avance │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ 📋 Gestión de Páginas              [+ Agregar Página]   │   │
│ │ ┌──────────┐ ┌──────────┐ ┌──────────┐                  │   │
│ │ │📄 Página 1│ │📄 Página 2│ │📄 Página 3│                  │   │
│ │ │   (5)     │ │   (3)     │ │   (2)     │                  │   │
│ │ └──────────┘ └──────────┘ └──────────┘                  │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ Campos del Formulario:                                         │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ 🔤 Texto   📧 Email   📞 Teléfono                       │   │
│ │ #️⃣ Número   📅 Fecha    📋 Selección                    │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ ▤ Nombre Completo                        🗑️              │   │
│ │ Etiqueta: [Nombre Completo      ] ID: [campo_1        ] │   │
│ │ Página: [Página 1 ▼]            ☑ Obligatorio           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ ▤ Correo Electrónico                     🗑️              │   │
│ │ Etiqueta: [Correo          ] ID: [campo_2        ]       │   │
│ │ Página: [Página 1 ▼]        ☑ Obligatorio               │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│                        [Cancelar]  [💾 Guardar Formulario]     │
└─────────────────────────────────────────────────────────────────┘
```

## 2. Public Form (User View) - Page 1
```
┌─────────────────────────────────────────────────────────────────┐
│                   Solicitud de Visa Americana                   │
│                         🗺️ Visa | Primera Vez                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ Progreso del Formulario                           40%   │   │
│ │ ███████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │   │
│ │ Página 1 de 3                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │                                                           │   │
│ │ Nombre Completo *                                         │   │
│ │ [Juan Pérez García                                    ]   │   │
│ │                                                           │   │
│ │ Correo Electrónico *                                      │   │
│ │ [juan.perez@email.com                                 ]   │   │
│ │                                                           │   │
│ │ Teléfono *                                                │   │
│ │ [442-123-4567                                         ]   │   │
│ │                                                           │   │
│ │ Fecha de Nacimiento *                                     │   │
│ │ [1990-05-15                                           ]   │   │
│ │                                                           │   │
│ │ CURP *                                                    │   │
│ │ [PEGJ900515HQTRZN01                                   ]   │   │
│ │                                                           │   │
│ │ ☁️ ✓ Guardado                                             │   │
│ │                                                           │   │
│ │              [💾 Guardar Borrador]  [Siguiente →]         │   │
│ │                                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ 🔒 Tus datos están protegidos                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 3. Public Form (User View) - Page 2
```
┌─────────────────────────────────────────────────────────────────┐
│                   Solicitud de Visa Americana                   │
│                         🗺️ Visa | Primera Vez                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ Progreso del Formulario                           70%   │   │
│ │ ██████████████████████████████████░░░░░░░░░░░░░░░░░░░░  │   │
│ │ Página 2 de 3                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │                                                           │   │
│ │ Número de Pasaporte *                                     │   │
│ │ [M123456789                                           ]   │   │
│ │                                                           │   │
│ │ Motivo del Viaje *                                        │   │
│ │ [Turismo ▼                                            ]   │   │
│ │                                                           │   │
│ │ Dirección en México *                                     │   │
│ │ ┌──────────────────────────────────────────────────┐   │   │
│ │ │ Calle Reforma 123, Colonia Centro              │   │   │
│ │ │ Querétaro, Qro. 76000                            │   │   │
│ │ │                                                    │   │   │
│ │ └──────────────────────────────────────────────────┘   │   │
│ │                                                           │   │
│ │ ☁️ Guardando...                                           │   │
│ │                                                           │   │
│ │         [← Anterior]              [Siguiente →]           │   │
│ │                                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ 🔒 Tus datos están protegidos                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 4. Public Form (User View) - Final Page with PayPal
```
┌─────────────────────────────────────────────────────────────────┐
│                   Solicitud de Visa Americana                   │
│                         🗺️ Visa | Primera Vez                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ Progreso del Formulario                          100%   │   │
│ │ ████████████████████████████████████████████████████████  │   │
│ │ Página 3 de 3                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │                                                           │   │
│ │ Copia del Pasaporte *                                     │   │
│ │ [📎 Elegir archivo]  pasaporte.pdf                       │   │
│ │   📄 Formatos: PDF, JPG, PNG (Máx. 10MB)                │   │
│ │                                                           │   │
│ │ Acta de Nacimiento *                                      │   │
│ │ [📎 Elegir archivo]  acta.pdf                            │   │
│ │   📄 Formatos: PDF, JPG, PNG (Máx. 10MB)                │   │
│ │                                                           │   │
│ │ ☁️ ✓ Guardado                                             │   │
│ │                                                           │   │
│ │    [← Anterior]  [💾 Guardar Borrador]  [📤 Enviar]      │   │
│ │                                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ 💳 Información de Pago                                   │   │
│ │ ┌─────────────────────────────────────────────────────┐ │   │
│ │ │ Costo del servicio: $1,500.00 MXN                   │ │   │
│ │ │                                                      │ │   │
│ │ │ Después de enviar el formulario, recibirás un       │ │   │
│ │ │ enlace de pago de PayPal en tu correo electrónico.  │ │   │
│ │ └─────────────────────────────────────────────────────┘ │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ 🔒 Tus datos están protegidos                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 5. Success Message
```
┌─────────────────────────────────────────────────────────────────┐
│                   Solicitud de Visa Americana                   │
│                         🗺️ Visa | Primera Vez                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ ✅                                                         │   │
│ │                                                           │   │
│ │ ¡Formulario Enviado Exitosamente!                        │   │
│ │                                                           │   │
│ │ Gracias por completar el formulario. Hemos recibido      │   │
│ │ tu información y te contactaremos pronto.                │   │
│ │                                                           │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────┐   │
│ │ 💳 Información de Pago                                   │   │
│ │ ┌─────────────────────────────────────────────────────┐ │   │
│ │ │ Costo del servicio: $1,500.00 MXN                   │ │   │
│ │ │                                                      │ │   │
│ │ │ Después de enviar el formulario, recibirás un       │ │   │
│ │ │ enlace de pago de PayPal en tu correo electrónico.  │ │   │
│ │ └─────────────────────────────────────────────────────┘ │   │
│ └─────────────────────────────────────────────────────────┘   │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Key Features Illustrated

### ✅ Page Management (Admin)
- Multiple pages with field counts shown in tabs
- Drag-and-drop field creation
- Dropdown to assign fields to pages
- Visual feedback on current page

### ✅ Navigation (User)
- "Anterior" button (hidden on page 1)
- "Siguiente" button (hidden on last page)  
- "Enviar" button (only on last page)
- Page indicator shows position (Página X de Y)

### ✅ Progress Tracking
- Visual progress bar updates in real-time
- Percentage displayed (e.g., 40%, 70%, 100%)
- Calculates across ALL pages correctly
- Handles radio buttons and checkboxes properly

### ✅ Auto-Save
- Triggers after 3 seconds of no input
- Saves when navigating between pages
- Visual feedback: "Guardando..." → "✓ Guardado"
- Stores submission ID for continuity

### ✅ PayPal Integration
- Always visible at bottom
- Shows service cost clearly
- Provides payment instructions
- Unaffected by pagination

### ✅ User Experience
- Fields automatically hidden/shown per page
- Cannot navigate if validation fails
- Progress preserved across sessions
- Clear visual hierarchy
- Mobile-responsive design
